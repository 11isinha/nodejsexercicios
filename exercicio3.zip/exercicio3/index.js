const colors = require('colors');

console.log('🍞 Bem-vindo à padaria do João!'.rainbow);
console.log('Pães Frescos todos os dias!'.green);
console.log('Horário: 6h às 18h'.blue);